public class Noeud
{
    public int px=0;
    public int p999=0;

    public Noeud(int px, int p999) {
        this.px=px;
        this.p999=p999;
    }
}